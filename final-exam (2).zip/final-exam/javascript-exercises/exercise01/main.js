function color1() {
    // target the element with the id of square1
    querySelector()
    // and change its background color...
}

function color2() {
    // target the element with the id of square2
    // and change its background color...
}

function color3() {
    // TODO
}

function color4() {
    // TODO
}

function color5() {
    // TODO
}

function color6() {
    // TODO
}