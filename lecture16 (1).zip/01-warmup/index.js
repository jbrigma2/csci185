function toggleFall() {
    /*
        Your task: target the body element and change it's class to "fall"
    */
}

function toggleWinter() {
    /*
        Your task: target the body element and change it's class to "winter"
    */
}

function toggleSpring() {
    /*
        Your task: target the body element and change it's class to "spring"
    */
}